Jofin
 
 1.Related Products
 2.Product Gallery & description section
 

 Arun 

 1. Recently viewed section
 2. Pin code checker
 


 done in => Products.vue,RelatedProducts.vue
 
 Bootstrap is used here, need to install bootstrap, 
 https://bootstrap-vue.org/docs

<template>
  <b>Please implement vendor-specific ProfileUpdateForm component in the 'components/MyAccount' directory</b>
</template>

<script>
export default {
  name: 'ProfileUpdateForm'
};
</script>

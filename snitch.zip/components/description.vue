<template>
   <div class="container pt-5 mt-5">
     <div class="middle row"> 
       <div class="col-md-4 col-12">
         <h5 class="pb-4">PRODUCT SPECIFICATION</h5>         
         <span>Anti-Dust</span> <h5/>        
         <span>Distressed Finish</span><h5/>  
         <span>Comfort Stretch</span><h5/>  
         <span>Angle length</span><h5/>  
         <span></span>         

         </div>
         <div class="col-md-4 col-12">
           <h5>FABRIC :</h5>
           <span>97% Cotton; 3% Elastane</span><br><br>
           <h5>FIT :</h5>
           <span>Skinny Fit</span><br><br>
         </div>       
         <div class="col-md-4 col-12">
           <h5 class="h5">SIZE:  <span>Model is wearing a size 32</span></h5>
           <h5 class="h5">Model Height:  <span>6 Feet</span></h5>
           <h5 class="h5">CARE:  <span>Cold machine wash.For some more details see the wash care label attached</span></h5>
            <h5 class="h5">EST.Order Processing Time:  <span class="spn">48-72hrs</span></h5>
            
            <h5 class="h5">Estimated Delivery:  <span>4-7 Days</span></h5>
            <p>Actual color of the product may vary slightly due to photographic lightning source or your device.</p>


         </div>  
         
         </div>   
                          
        </div>         

</template>

<script>
export default {

}
</script>

<style scoped>



h5 {
   font-weight: 500;
    letter-spacing: .8px;
    color: #000;
    margin-bottom: 15px;
    display: block;
    font-size: 16px;
    font-family: Jost,sans-serif;
}
span {
    font-family: Jost,sans-serif;
    letter-spacing: .04em;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    -webkit-text-size-adjust: 100%;
     list-style: none;
    font-weight: 100;
    color: grey;
}
p {
    font-weight: 500;
    letter-spacing: .8px;
    color: #000;
    margin-bottom: 15px;
    display: block;
    font-family: Jost,sans-serif;
    line-height: 1.6;
    font-size: 16px;
}
.h5 {
  font-weight: 700;
  color: grey;
      margin-bottom: 15px;
          font-size: 16px;
              font-family: Jost,sans-serif;
    letter-spacing: .04em;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    -webkit-text-size-adjust: 100%;
    text-rendering: optimizeSpeed;

}
@media only screen and (max-width: 600px) { 
h5 {
   font-size: 14.4px;
    letter-spacing: .04em;
    line-height: 1.6;
}
span {
    font-size: 14.4px;
    letter-spacing: .04em;
    line-height: 1.6;
}
p {
    font-size: 14.4px;
    letter-spacing: .04em;
    line-height: 1.6;
}
.h5 {
  font-weight: 700;  
font-size: 14.4px;
    letter-spacing: .04em;
    line-height: 1.6;
} 
}
</style>
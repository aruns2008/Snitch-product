Put here platform-specific, non-agnostic functions that overwrite default code.
